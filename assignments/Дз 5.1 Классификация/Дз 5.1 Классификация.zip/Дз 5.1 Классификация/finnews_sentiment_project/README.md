# Финансовые новости — анализ тональности для трейдеров

Этот проект посвящён задаче классификации тональности финансовых новостей
(positive / negative / neutral) с точки зрения трейдера.

## Структура проекта

- `data/raw/` — сырые данные, исходные CSV/Parquet с новостями.
- `data/processed/` — очищенные и подготовленные датасеты для обучения.
- `models/` — сохранённые модели, пайплайны и артефакты (joblib/pickle).
- `notebooks/` — Jupyter ноутбуки для EDA, экспериментов и отчётов.
- `reports/` — графики, таблицы и презентации.
- `src/finnews_sentiment/` — основной исходный код проекта:
  - `data/` — загрузка и первичная обработка данных.
  - `features/` — предобработка текста и генерация признаков.
  - `models/` — обучение, оценка и инференс моделей.
  - `visualization/` — вспомогательные функции для графиков.
- `configs/` — конфигурационные файлы (yaml/json) для экспериментов.
- `scripts/` — скрипты для запуска пайплайна из консоли.

## Быстрый старт

1. Установить зависимости:

   ```bash
   pip install -r requirements.txt
   ```

2. Положить датасет с новостями в `data/raw/` (например, `news.csv`).

3. Запустить базовую подготовку данных:

   ```bash
   python -m finnews_sentiment.data.load_data --input data/raw/news.csv --output data/processed/clean_news.csv
   ```

4. Обучить модель (будущий скрипт):

   ```bash
   python -m finnews_sentiment.models.train_model --config configs/train_baseline.yaml
   ```

5. Сделать предсказание для новых новостей:

   ```bash
   python -m finnews_sentiment.models.predict --model models/best_model.joblib --input data/raw/new_news.csv
   ```

Все шаги детально описаны в README и ноутбуках в папке `notebooks/`.